package com.huanyunews.news.controller;

import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.List;

public class ArticleControllerTest extends TestCase {

    @Test
    public void getArticlestest(HttpSession session) {

        String t_user_account = session.getAttribute("t_user").toString();
        List article = mapper.getUserAllArticles(t_user_account);

        System.out.println(article.get(0));
    }


    public void xw_getArticles() {

        List article = mapper.getAllArticles();
        System.out.println(article);

    }

    @Test
    public void deleteArticle(String t_article_id) {
        t_article_id = "";
        System.out.println("t_article_id");
        if (mapper.deleteById(t_article_id)) {
            List article = mapper.getAllArticles();

            System.out.println("删除成功"+article);

        } else {
            List article = mapper.getAllArticles();

            String error = "删除失败？？？";
            System.out.println(error+article);
        }

    }

}