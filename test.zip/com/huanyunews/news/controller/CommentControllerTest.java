package com.huanyunews.news.controller;

import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * comment增删改查测试
 */
public class CommentControllerTest extends TestCase {

    /**
     * 查询所有
     */
    @Test
    public void countComment() {
        List list = mapper.countAllComment();
        System.out.println(list.size());
    }

    /**
     * 内容添加测试
     * @param account
     * @return
     */
    @Test
    public void UserCountComment(String account) {
        account = "";
        int count = mapper.UserComCount(account);
        if (count != 0){
            System.out.println("成功");
        }
    }

    /**
     * 删除测试
     * @param id
     * @return
     */
    @Test
    public void deleteComment(@PathVariable("id") int id) {
        id=1;
        mapper.deleteById(id);
        Map map1 = new HashMap();
    }

}