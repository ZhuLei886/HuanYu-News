package com.huanyunews.news.controller;

import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.util.List;

/**
 * 新闻测试
 */
public class NodeControllerTest extends TestCase {

    /**
     * 查询所有
     */
    @Test
    public void gets(){
        List node=mapper.getAllNodes();
        System.out.println(node);
    }

    /**
     * 根据id删除
     * @param t_user_id
     * @return
     */
    @Test
    public void deleteUser(String t_user_id) {
       t_user_id="1";
        if (mapper.deleteById(t_user_id)) {
            List users = mapper.getAllUsers();

            String success = "删除成功！";
            System.out.println(success);

        } else {
            List users = mapper.getAllUsers();

            String error = "删除失败？？？";
            System.out.println(error);
        }

    }

}