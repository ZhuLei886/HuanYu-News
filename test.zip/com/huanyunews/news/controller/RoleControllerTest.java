package com.huanyunews.news.controller;

import junit.framework.TestCase;
import org.junit.Test;
import org.springframework.web.servlet.ModelAndView;

public class RoleControllerTest extends TestCase

    //所有
    @Test
    public ModelAndView getRoles() {

    List role = mapper.getAllRoles();
        System.out.println("role"+role);
    }



}