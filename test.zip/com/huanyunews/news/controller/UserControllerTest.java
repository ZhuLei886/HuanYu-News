package com.huanyunews.news.controller;

import junit.framework.TestCase;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserControllerTest extends TestCase {

    /**
     * 登录查询测试
     */
    public void userLogin(String t_user_account, String t_user_password, HttpSession session) {
        //在数据库中检验浏览器提交上来的数据
       t_user_account="";
       t_user_password="";

        List<Map<String, Object>> list = mapper.userLogin(t_user_account, t_user_password);
        Map t_user_id = mapper.userLogin2(t_user_account, t_user_password);
        System.out.println(list.size());


    }

    /**
     * 所有用户
     * @return
     */
    public void getUsers() {    ModelAndView mv = new ModelAndView();
        List users = mapper.getAllUsers();
        System.out.println(users.size());


    }

    /**
     * 改密码
     */
    public void NewPassWord() {
        String password = "123132";
        int i = mapper.NewPassWord(password);
        System.out.println(i);
    }
}